"""Build the deduplicated master job table from all production sources."""

from __future__ import annotations

import logging
import time

from sqlalchemy import text
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session

from app.db.postgres import PostgresClient

logger = logging.getLogger("placeup.etl.master_jobs")

# Every worker eventually publishes into the same master_jobs rows. A
# non-blocking transaction lock prevents two full-table publishers from
# interleaving their ON CONFLICT updates. Skipping is safe: source rows have
# already committed and the next incremental/scheduled publication includes
# them. Non-blocking acquisition is important because some callers arrive
# here after writing source rows in their current transaction; waiting while
# holding those locks can itself form a deadlock cycle.
MASTER_REBUILD_LOCK_KEY = 6412226682827
MASTER_REBUILD_LOCK_SQL = "SELECT pg_try_advisory_xact_lock(:lock_key)"
MASTER_SYNC_MAX_ATTEMPTS = 3
MASTER_SYNC_RETRY_DELAYS_SECONDS = (0.25, 0.75)


MASTER_SYNC_SQL = """
WITH source_rows AS (
    SELECT
        j.id::text AS id,
        encode(digest(lower(trim(coalesce(j.title, ''))) || '|' || lower(trim(coalesce(c.name, ''))) || '|' || lower(trim(coalesce(j.location, ''))), 'sha256'), 'hex') AS canonical_key,
        j.title,
        coalesce(c.name, '') AS company,
        j.location,
        j.country,
        j.source_name,
        j.source_job_id,
        j.source_url,
        j.description,
        j.employment_type,
        j.remote_type,
        j.salary_min,
        j.salary_max,
        j.currency,
        j.visa_opt,
        j.visa_stem_opt,
        j.visa_h1b,
        j.h1b_verified,
        j.visa_score,
        j.status,
        j.posted_at,
        j.first_seen_at,
        j.last_seen_at,
        10 AS source_priority,
        jsonb_build_array(j.source_name) AS merged_sources,
        coalesce(j.extra_metadata, '{}'::jsonb) || jsonb_build_object('source_table', 'jobs', 'category', j.category) AS extra_metadata
    FROM jobs j
    LEFT JOIN companies c ON c.id = j.company_id
    WHERE coalesce(j.title, '') <> ''

    UNION ALL

    SELECT
        ('silver_' || sp.job_id::text) AS id,
        encode(digest(lower(trim(coalesce(sp.title, ''))) || '|' || lower(trim(coalesce(sp.organization, ''))) || '|' || lower(trim(coalesce(sp.full_location, sp.city, ''))), 'sha256'), 'hex') AS canonical_key,
        sp.title,
        coalesce(sp.organization, '') AS company,
        coalesce(sp.full_location, sp.city, sp.region, sp.country, '') AS location,
        sp.country,
        coalesce(sp.source, sp.source_type, 'silver_loader') AS source_name,
        sp.job_id::text AS source_job_id,
        sp.job_url AS source_url,
        sp.description_text AS description,
        array_to_string(sp.employment_type, ', ') AS employment_type,
        sp.location_type AS remote_type,
        NULL::numeric AS salary_min,
        NULL::numeric AS salary_max,
        'USD' AS currency,
        false AS visa_opt,
        false AS visa_stem_opt,
        false AS visa_h1b,
        false AS h1b_verified,
        0 AS visa_score,
        CASE WHEN sp.is_active THEN 'active' ELSE 'inactive' END AS status,
        sp.date_posted AS posted_at,
        sp.silver_created_at AS first_seen_at,
        sp.silver_updated_at AS last_seen_at,
        30 AS source_priority,
        jsonb_build_array(coalesce(sp.source, sp.source_type, 'silver_loader')) AS merged_sources,
        jsonb_build_object(
            'source_table', 'silver_posts',
            'organization_url', sp.organization_url,
            'source_domain', sp.source_domain,
            'employer_domain', sp.employer_domain,
            'locations_raw', sp.locations_raw,
            'salary_raw', sp.salary_raw
        ) AS extra_metadata
    FROM silver_posts sp
    WHERE coalesce(sp.title, '') <> ''
),
ranked AS (
    SELECT *,
        row_number() OVER (
            PARTITION BY canonical_key
            ORDER BY source_priority ASC, coalesce(posted_at, last_seen_at) DESC NULLS LAST
        ) AS rn,
        min(first_seen_at) OVER (PARTITION BY canonical_key) AS min_first_seen_at,
        max(last_seen_at) OVER (PARTITION BY canonical_key) AS max_last_seen_at
    FROM source_rows
),
source_groups AS (
    SELECT canonical_key, jsonb_agg(DISTINCT source_name) AS all_sources
    FROM source_rows
    GROUP BY canonical_key
)
INSERT INTO master_jobs (
    id, canonical_key, title, company, location, country, source_name, source_job_id,
    source_url, description, employment_type, remote_type, salary_min, salary_max,
    currency, visa_opt, visa_stem_opt, visa_h1b, h1b_verified, visa_score, status,
    posted_at, first_seen_at, last_seen_at, source_priority, merged_sources, extra_metadata
)
SELECT
    canonical_key AS id, canonical_key, title, company, location, country, source_name, source_job_id,
    source_url, description, employment_type, remote_type, salary_min, salary_max,
    currency, visa_opt, visa_stem_opt, visa_h1b, h1b_verified, visa_score, status,
    posted_at, min_first_seen_at, max_last_seen_at, source_priority, sg.all_sources, extra_metadata
FROM ranked
JOIN source_groups sg USING (canonical_key)
WHERE rn = 1
ORDER BY canonical_key
ON CONFLICT (canonical_key) DO UPDATE SET
    title = EXCLUDED.title,
    company = EXCLUDED.company,
    location = EXCLUDED.location,
    country = EXCLUDED.country,
    source_name = EXCLUDED.source_name,
    source_job_id = EXCLUDED.source_job_id,
    source_url = EXCLUDED.source_url,
    description = EXCLUDED.description,
    employment_type = EXCLUDED.employment_type,
    remote_type = EXCLUDED.remote_type,
    salary_min = EXCLUDED.salary_min,
    salary_max = EXCLUDED.salary_max,
    currency = EXCLUDED.currency,
    visa_opt = EXCLUDED.visa_opt,
    visa_stem_opt = EXCLUDED.visa_stem_opt,
    visa_h1b = EXCLUDED.visa_h1b,
    h1b_verified = EXCLUDED.h1b_verified,
    visa_score = EXCLUDED.visa_score,
    status = EXCLUDED.status,
    posted_at = EXCLUDED.posted_at,
    last_seen_at = EXCLUDED.last_seen_at,
    source_priority = EXCLUDED.source_priority,
    merged_sources = EXCLUDED.merged_sources,
    extra_metadata = EXCLUDED.extra_metadata;
"""


def try_acquire_master_jobs_lock(db: Session) -> bool:
    """Return whether this transaction owns the shared master_jobs writer lock."""
    return bool(
        db.execute(
            text(MASTER_REBUILD_LOCK_SQL),
            {"lock_key": MASTER_REBUILD_LOCK_KEY},
        ).scalar()
    )


def _is_deadlock(exc: OperationalError) -> bool:
    original = getattr(exc, "orig", None)
    sqlstate = getattr(original, "sqlstate", None) or getattr(original, "pgcode", None)
    return sqlstate == "40P01"


def _rebuild_in_session(db: Session) -> int:
    acquired = try_acquire_master_jobs_lock(db)
    if not acquired:
        logger.warning(
            "Master jobs sync skipped: another publisher currently owns lock %s",
            MASTER_REBUILD_LOCK_KEY,
        )
        return 0

    # The advisory lock coordinates all current publishers, while the nested
    # transaction protects source rows already written by callers. If an old
    # or external writer that does not yet honor the lock causes PostgreSQL to
    # choose this statement as a 40P01 deadlock victim, rolling back only the
    # savepoint lets us retry without losing those collected source jobs.
    for attempt in range(1, MASTER_SYNC_MAX_ATTEMPTS + 1):
        try:
            with db.begin_nested():
                result = db.execute(text(MASTER_SYNC_SQL))
            count = int(result.rowcount or 0)
            logger.info("Master jobs sync complete: %s rows upserted", count)
            return count
        except OperationalError as exc:
            if not _is_deadlock(exc) or attempt >= MASTER_SYNC_MAX_ATTEMPTS:
                raise
            delay = MASTER_SYNC_RETRY_DELAYS_SECONDS[attempt - 1]
            logger.warning(
                "Master jobs sync deadlocked on attempt %s/%s; retrying in %.2fs",
                attempt,
                MASTER_SYNC_MAX_ATTEMPTS,
                delay,
            )
            time.sleep(delay)

    raise RuntimeError("Master jobs sync retry loop exhausted")  # pragma: no cover


def rebuild_master_jobs(client: PostgresClient | Session | None = None, *, db: Session | None = None) -> int:
    if db is not None:
        return _rebuild_in_session(db)

    if isinstance(client, Session):
        return _rebuild_in_session(client)

    client = client or PostgresClient()
    with client.session() as db:
        return _rebuild_in_session(db)


def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    rebuild_master_jobs()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
