# Shared utilities
