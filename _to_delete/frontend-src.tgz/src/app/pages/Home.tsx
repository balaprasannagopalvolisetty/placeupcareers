import { useEffect, useState } from "react";
import { motion } from "motion/react";
import { Link } from "react-router";
import {
  ArrowRight, Target, Mail, Shield, BarChart3,
  Users, Bell, Mic, Check, Send, MapPin, Phone, Globe,
  FileText, Search, Sparkles, CreditCard,
} from "lucide-react";
import { Navbar } from "../components/Navbar";
import { BrandLogo } from "../components/BrandLogo";
import * as api from "../lib/api";

// ─── Design tokens: clean, light, professional SaaS ───
const T = {
  bg:        "var(--pu-ffffff-b)",
  bgAlt:     "var(--pu-f8fafc-b)",
  card:      "var(--pu-ffffff-b)",
  border:    "var(--pu-e2e8f0-b)",
  text:      "var(--pu-0f172a-t)",
  t2:        "var(--pu-475569-t)",
  t3:        "var(--pu-64748b-t)",
  accent:    "var(--pu-2563eb)",
  accentDeep:"var(--pu-1d4ed8)",
  grad:      "linear-gradient(135deg, var(--pu-2563eb), var(--pu-0ea5e9))",
  shadow:    "0 1px 3px var(--pu-15-23-42-006), 0 8px 24px var(--pu-15-23-42-005)",
  shadowH:   "0 4px 12px var(--pu-15-23-42-008), 0 16px 40px var(--pu-15-23-42-01)",
};
const F = { sans: "'Plus Jakarta Sans', sans-serif" };

function useViewportFlags() {
  const getWidth = () => (typeof window === "undefined" ? 1280 : window.innerWidth);
  const [width, setWidth] = useState(getWidth);
  useEffect(() => {
    const onResize = () => setWidth(getWidth());
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);
  return { isMobile: width < 680 };
}

function Reveal({ children }: { children: React.ReactNode; delay?: number; y?: number }) {
  return <div>{children}</div>;
}

function SectionTag({ text }: { text: string }) {
  return (
    <div style={{ display: "flex", justifyContent: "center", marginBottom: 16 }}>
      <span style={{
        display: "inline-block", padding: "6px 14px", borderRadius: 9999,
        background: "var(--pu-37-99-235-008)", border: "1px solid var(--pu-37-99-235-018)",
        fontSize: 12, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase",
        color: T.accent, fontFamily: F.sans,
      }}>{text}</span>
    </div>
  );
}

function Card({ children, style = {}, hover = true }: {
  children: React.ReactNode; style?: React.CSSProperties; hover?: boolean;
}) {
  return (
    <motion.div
      whileHover={hover ? { y: -4, boxShadow: T.shadowH } : undefined}
      transition={{ duration: 0.25 }}
      style={{
        background: T.card,
        border: `1px solid ${T.border}`,
        borderRadius: 16,
        boxShadow: T.shadow,
        ...style,
      }}
    >{children}</motion.div>
  );
}

// ═══════════════════════════
// MAIN HOME PAGE
// ═══════════════════════════
export default function Home() {
  return (
    <div style={{ background: T.bg, position: "relative", fontFamily: F.sans }}>
      <Navbar />
      <HeroSection />
      <HowItWorksSection />
      <FeaturesSection />
      <PricingSection />
      <ContactSection />
      <Footer />
    </div>
  );
}

// ═══════════════════════════
// 1. HERO
// ═══════════════════════════
function HeroSection() {
  const { isMobile } = useViewportFlags();
  const [liveJobs, setLiveJobs] = useState<number | null>(null);
  const [liveCategories, setLiveCategories] = useState<number | null>(null);

  useEffect(() => {
    let active = true;
    api.getJobStats()
      .then((s) => {
        if (!active) return;
        if (typeof s?.total_jobs === "number") setLiveJobs(s.total_jobs);
        const cats = s?.by_category ? Object.keys(s.by_category).length : 0;
        if (cats) setLiveCategories(cats);
      })
      .catch(() => {});
    return () => { active = false; };
  }, []);

  const jobsLabel = liveJobs && liveJobs > 0
    ? (liveJobs >= 1000 ? `${(liveJobs / 1000).toFixed(liveJobs >= 10000 ? 0 : 1)}k+` : `${liveJobs}+`)
    : "1k+";
  const stats = [
    { val: jobsLabel, label: "Live roles" },
    { val: liveCategories ? String(liveCategories) : "10", label: "Categories" },
    { val: "32", label: "Countries" },
    { val: "6hr", label: "Refresh" },
  ];

  return (
    <section style={{
      paddingTop: isMobile ? 120 : 150, paddingBottom: isMobile ? 64 : 96,
      background: `radial-gradient(1200px 500px at 50% -10%, var(--pu-37-99-235-007), transparent 70%), ${T.bg}`,
      position: "relative",
    }}>
      <div style={{ maxWidth: 860, margin: "0 auto", padding: "0 24px", textAlign: "center" }}>
        {/* Status badge */}
        <Reveal delay={0.05} y={12}>
          <div style={{
            display: "inline-flex", alignItems: "center", gap: 8, padding: "8px 16px",
            borderRadius: 9999, marginBottom: 28,
            background: "var(--pu-37-99-235-006)", border: "1px solid var(--pu-37-99-235-016)",
          }}>
            <span style={{ width: 7, height: 7, borderRadius: "50%", background: "var(--pu-22c55e-b)", boxShadow: "0 0 0 3px var(--pu-34-197-94-018)" }} />
            <span style={{ fontSize: 12.5, fontWeight: 600, color: T.accent, fontFamily: F.sans }}>
              Visa-friendly roles in 32 countries, refreshed every 6 hours
            </span>
          </div>
        </Reveal>

        {/* Headline */}
        <Reveal delay={0.12}>
          <h1 style={{
            fontFamily: F.sans, fontSize: "clamp(38px, 6vw, 68px)", fontWeight: 800,
            lineHeight: 1.08, letterSpacing: "-0.03em", color: T.text, marginBottom: 22,
          }}>
            Land your dream job,{" "}
            <span style={{ background: T.grad, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
              anywhere in the world
            </span>
          </h1>
        </Reveal>

        {/* Subheading */}
        <Reveal delay={0.2}>
          <p style={{
            fontSize: 18, lineHeight: 1.7, color: T.t2, fontFamily: F.sans,
            maxWidth: 620, margin: "0 auto 36px",
          }}>
            Freshly posted, visa-friendly roles across 32 countries, including H-1B, EU Blue Card,
            Skilled Worker, and Employment Pass. Every job is scored against your resume in real time,
            so you apply only where you can actually get hired and sponsored.
          </p>
        </Reveal>

        {/* CTA buttons */}
        <Reveal delay={0.28}>
          <div style={{ display: "flex", gap: 14, marginBottom: 52, flexWrap: "wrap", justifyContent: "center" }}>
            <Link to="/signup" style={{
              display: "inline-flex", alignItems: "center", gap: 8,
              padding: "15px 30px", borderRadius: 12, background: T.grad,
              color: "var(--pu-ffffff-t)", fontSize: 16, fontWeight: 700, fontFamily: F.sans,
              textDecoration: "none", boxShadow: "0 8px 24px var(--pu-37-99-235-028)",
            }}>
              Get started free <ArrowRight size={17} />
            </Link>
            <button
              onClick={() => document.getElementById("how-it-works")?.scrollIntoView({ behavior: "smooth" })}
              style={{
                display: "inline-flex", alignItems: "center", gap: 8,
                padding: "15px 26px", borderRadius: 12,
                background: "var(--pu-ffffff-b)", border: `1px solid ${T.border}`,
                color: T.text, fontSize: 16, fontFamily: F.sans, fontWeight: 600,
                cursor: "pointer", boxShadow: T.shadow,
              }}>
              How it works
            </button>
          </div>
        </Reveal>

        {/* Stats row */}
        <div style={{ display: "flex", gap: 12, flexWrap: "wrap", justifyContent: "center" }}>
          {stats.map((s, i) => (
            <Reveal key={s.label} delay={0.34 + i * 0.06} y={16}>
              <Card style={{ padding: "18px 26px", textAlign: "center", minWidth: 112 }}>
                <div style={{
                  fontFamily: F.sans, fontSize: 26, fontWeight: 800, lineHeight: 1,
                  background: T.grad, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
                  marginBottom: 6,
                }}>{s.val}</div>
                <div style={{ fontSize: 13, color: T.t3, fontFamily: F.sans, fontWeight: 500 }}>{s.label}</div>
              </Card>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

// ═══════════════════════════
// 2. HOW IT WORKS
// ═══════════════════════════
const steps = [
  {
    icon: FileText, step: "01", title: "Upload your resume",
    desc: "Add your resume once. We parse your skills, experience, and target roles to build your matching profile.",
  },
  {
    icon: Search, step: "02", title: "We find visa-friendly jobs",
    desc: "Our pipeline collects fresh postings from Greenhouse, Workday, Lever, Ashby, iCIMS, BambooHR, SmartRecruiters, and similar official career systems across 32 countries.",
  },
  {
    icon: Sparkles, step: "03", title: "Every job is scored for you",
    desc: "Each posting gets an ATS match score against your resume, with a keyword-level breakdown of what is strong and what is missing.",
  },
  {
    icon: Target, step: "04", title: "Apply where you can win",
    desc: "Apply directly at the source with confidence, track every application, and review fresh top matches every day.",
  },
];

function HowItWorksSection() {
  const { isMobile } = useViewportFlags();
  return (
    <section id="how-it-works" style={{ padding: isMobile ? "64px 0" : "96px 0", background: T.bgAlt }}>
      <div style={{ maxWidth: 1140, margin: "0 auto", padding: "0 24px" }}>
        <Reveal><SectionTag text="How it works" /></Reveal>
        <Reveal delay={0.08}>
          <h2 style={{
            fontFamily: F.sans, fontWeight: 800, fontSize: "clamp(28px, 4vw, 44px)",
            lineHeight: 1.15, letterSpacing: "-0.02em", textAlign: "center",
            color: T.text, marginBottom: 14,
          }}>
            From resume to offer, in four steps
          </h2>
        </Reveal>
        <Reveal delay={0.12}>
          <p style={{ textAlign: "center", fontSize: 16, color: T.t2, fontFamily: F.sans, maxWidth: 560, margin: "0 auto 52px", lineHeight: 1.7 }}>
            No endless scrolling through job boards. We do the searching, screening, and scoring so you can focus on applying well.
          </p>
        </Reveal>
        <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "repeat(auto-fit, minmax(240px, 1fr))", gap: 18 }}>
          {steps.map((s, i) => (
            <Reveal key={s.step} delay={0.15 + i * 0.07}>
              <Card style={{ padding: 28, height: "100%" }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 18 }}>
                  <div style={{
                    width: 44, height: 44, borderRadius: 12, background: "var(--pu-37-99-235-008)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                  }}>
                    <s.icon size={20} color={T.accent} />
                  </div>
                  <span style={{ fontFamily: F.sans, fontSize: 13, fontWeight: 700, color: "var(--pu-cbd5e1-t)" }}>{s.step}</span>
                </div>
                <h3 style={{ fontFamily: F.sans, fontSize: 17, fontWeight: 700, color: T.text, marginBottom: 8 }}>{s.title}</h3>
                <p style={{ fontSize: 14.5, lineHeight: 1.65, color: T.t2, fontFamily: F.sans }}>{s.desc}</p>
              </Card>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

// ═══════════════════════════
// 3. FEATURES
// ═══════════════════════════
const features = [
  { icon: Shield, title: "Visa-Aware Job Matching", desc: "Every listing is screened for sponsorship signals such as F1-CPT, F1-OPT, STEM OPT, and H-1B, backed by real petition data, so you only apply where you are eligible." },
  { icon: Target, title: "Resume Match Scoring", desc: "See how your active resume scores against any posting before you apply, with a keyword-by-keyword breakdown of what is strong and what is missing." },
  { icon: Users, title: "Direct Company Links", desc: "We trace each posting back to the company's official careers page, so you apply at the source, where recruiters actually look first." },
  { icon: BarChart3, title: "Application Tracker", desc: "Applied, saved, and skipped roles in one dashboard, with dates and statuses, so you never duplicate effort or lose track of a follow-up." },
  { icon: Bell, title: "Smart Daily Matches", desc: "Your top matches refreshed every day, pre-filtered by visa status, role, and location. No noise, just jobs worth your time." },
  { icon: Mic, title: "Interview & Career Coaching", desc: "Elite members get one-on-one mock interviews, AI resume rewrites, and salary negotiation support from experienced US recruiters." },
];

function FeaturesSection() {
  const { isMobile } = useViewportFlags();
  return (
    <section id="features" style={{ padding: isMobile ? "64px 0" : "96px 0", background: T.bg }}>
      <div style={{ maxWidth: 1140, margin: "0 auto", padding: "0 24px" }}>
        <Reveal><SectionTag text="Features" /></Reveal>
        <Reveal delay={0.08}>
          <h2 style={{
            fontFamily: F.sans, fontWeight: 800, fontSize: "clamp(28px, 4vw, 44px)",
            lineHeight: 1.15, letterSpacing: "-0.02em", textAlign: "center",
            color: T.text, marginBottom: 52,
          }}>
            Everything you need to get hired
          </h2>
        </Reveal>
        <div style={{ display: "grid", gridTemplateColumns: `repeat(auto-fit, minmax(${isMobile ? "240px" : "300px"}, 1fr))`, gap: 18 }}>
          {features.map((f, i) => (
            <Reveal key={f.title} delay={0.1 + i * 0.06}>
              <Card style={{ padding: 28, height: "100%" }}>
                <div style={{
                  width: 44, height: 44, borderRadius: 12, background: T.grad,
                  display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 18,
                  boxShadow: "0 6px 16px var(--pu-37-99-235-022)",
                }}>
                  <f.icon size={20} color="var(--pu-ffffff-t)" />
                </div>
                <h3 style={{ fontFamily: F.sans, fontSize: 17, fontWeight: 700, color: T.text, marginBottom: 8 }}>{f.title}</h3>
                <p style={{ fontSize: 14.5, lineHeight: 1.65, color: T.t2, fontFamily: F.sans }}>{f.desc}</p>
              </Card>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

// ═══════════════════════════
// 5. CONTACT
// ═══════════════════════════
function PricingSection() {
  const { isMobile } = useViewportFlags();
  const [plans, setPlans] = useState<api.PaymentPlan[]>([]);

  useEffect(() => {
    let active = true;
    api.getPaymentPlans()
      .then((res) => { if (active) setPlans(Array.isArray(res.plans) ? res.plans : []); })
      .catch(() => {
        if (!active) return;
        setPlans([
          { id: "basic", name: "Basic", price: 9.99, interval: "m", features: ["Job matching", "Resume ATS score", "Saved jobs"] },
          { id: "pro", name: "Pro", price: 24.99, interval: "m", features: ["Everything in Basic", "Recruiter contacts", "Application tracking", "Priority job matches"] },
          { id: "elite", name: "Elite", price: 149.99, interval: "m", features: ["Everything in Pro", "Premium enrichment", "Visa sponsor insights", "Concierge support", "Dedicated employee applies for you to 25-30 filtered positions daily"] },
        ]);
      });
    return () => { active = false; };
  }, []);

  const displayPlans = plans.length ? plans : [
    { id: "basic", name: "Basic", price: 9.99, interval: "m", features: ["Job matching", "Resume ATS score", "Saved jobs"] },
    { id: "pro", name: "Pro", price: 24.99, interval: "m", features: ["Everything in Basic", "Recruiter contacts", "Application tracking", "Priority job matches"] },
    { id: "elite", name: "Elite", price: 149.99, interval: "m", features: ["Everything in Pro", "Premium enrichment", "Visa sponsor insights", "Concierge support", "Dedicated employee applies for you to 25-30 filtered positions daily"] },
  ] as api.PaymentPlan[];

  return (
    <section id="pricing" style={{ padding: isMobile ? "64px 0" : "96px 0", background: T.bgAlt }}>
      <div style={{ maxWidth: 1140, margin: "0 auto", padding: "0 24px" }}>
        <Reveal><SectionTag text="Pricing" /></Reveal>
        <Reveal delay={0.08}>
          <h2 style={{
            fontFamily: F.sans, fontWeight: 800, fontSize: "clamp(28px, 4vw, 44px)",
            lineHeight: 1.15, letterSpacing: "-0.02em", textAlign: "center",
            color: T.text, marginBottom: 12,
          }}>
            Choose the access level that fits your search
          </h2>
        </Reveal>
        <p style={{ textAlign: "center", fontSize: 15.5, color: T.t2, fontFamily: F.sans, maxWidth: 620, margin: "0 auto 38px", lineHeight: 1.7 }}>
          Straightforward monthly plans for different levels of search support, from self-serve matching to concierge application help.
        </p>
        <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "repeat(3, minmax(0, 1fr))", gap: 18 }}>
          {displayPlans.map((plan) => {
            const highlighted = plan.id === "pro";
            const price = Number(plan.price || 0);
            return (
              <Card key={plan.id} style={{ padding: 26, height: "100%", borderColor: highlighted ? "var(--pu-37-99-235-035)" : T.border }}>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", marginBottom: 16 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span style={{ width: 38, height: 38, borderRadius: 11, background: highlighted ? T.grad : "var(--pu-37-99-235-008)", display: "inline-flex", alignItems: "center", justifyContent: "center" }}>
                      <CreditCard size={17} color={highlighted ? "var(--pu-ffffff-b)" : T.accent} />
                    </span>
                    <span style={{ fontFamily: F.sans, fontSize: 18, fontWeight: 800, color: T.text }}>{plan.name}</span>
                  </div>
                  {highlighted && <span style={{ fontSize: 11, fontWeight: 800, color: T.accent, background: "var(--pu-37-99-235-008)", border: "1px solid var(--pu-37-99-235-018)", borderRadius: 999, padding: "4px 9px", fontFamily: F.sans }}>Popular</span>}
                </div>
                <div style={{ fontFamily: F.sans, fontSize: 34, fontWeight: 900, color: T.text, lineHeight: 1, marginBottom: 6 }}>
                  {price <= 0 ? "$0" : `$${price.toFixed(2)}`}
                  <span style={{ fontSize: 13, color: T.t3, fontWeight: 700 }}> / {plan.interval}</span>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 10, margin: "20px 0 24px" }}>
                  {(plan.features || []).map((feature) => (
                    <div key={feature} style={{ display: "flex", gap: 8, fontSize: 13.5, color: T.t2, fontFamily: F.sans, lineHeight: 1.45 }}>
                      <Check size={15} color="var(--pu-16a34a)" style={{ flexShrink: 0, marginTop: 1 }} />
                      {feature}
                    </div>
                  ))}
                </div>
                <Link to="/signup" style={{
                  display: "inline-flex", alignItems: "center", justifyContent: "center", width: "100%",
                  height: 44, borderRadius: 12, textDecoration: "none", fontSize: 14, fontWeight: 800,
                  fontFamily: F.sans, background: highlighted ? T.grad : "var(--pu-ffffff-b)", color: highlighted ? "var(--pu-ffffff-t)" : T.text,
                  border: highlighted ? "none" : `1px solid ${T.border}`,
                }}>
                  Select {plan.name}
                </Link>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function ContactSection() {
  const { isMobile } = useViewportFlags();
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [sent, setSent] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [contactError, setContactError] = useState("");

  const submitContact = async () => {
    setContactError("");
    if (!form.name.trim() || !form.email.trim() || !form.message.trim()) {
      setContactError("Please enter your name, email, and message.");
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) {
      setContactError("Please enter a valid email address.");
      return;
    }
    if (form.message.trim().length < 2) {
      setContactError("Please write a short message before sending.");
      return;
    }
    setSubmitting(true);
    try {
      await api.submitContactMessage({
        name: form.name.trim(),
        email: form.email.trim(),
        subject: form.subject || "General Inquiry",
        message: form.message.trim(),
      });
      setSent(true);
    } catch (err) {
      setContactError((err as Error).message || "Could not send your message. Please email operations@placeupcareer.com directly.");
    } finally {
      setSubmitting(false);
    }
  };

  const inputStyle: React.CSSProperties = {
    padding: "13px 15px", borderRadius: 10, border: `1px solid ${T.border}`,
    background: "var(--pu-ffffff-b)", color: T.text, fontSize: 14.5, fontFamily: F.sans,
    outline: "none", width: "100%",
  };

  return (
    <section id="contact" style={{ padding: isMobile ? "64px 0" : "96px 0", background: T.bg }}>
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "0 24px" }}>
        <Reveal><SectionTag text="Contact" /></Reveal>
        <Reveal delay={0.08}>
          <h2 style={{
            fontFamily: F.sans, fontWeight: 800, fontSize: "clamp(28px, 4vw, 44px)",
            lineHeight: 1.15, letterSpacing: "-0.02em", textAlign: "center",
            color: T.text, marginBottom: 48,
          }}>
            Get in touch
          </h2>
        </Reveal>

        <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 1.4fr", gap: 22 }}>
          {/* Contact info */}
          <Reveal delay={0.12}>
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {[
                { icon: Mail, label: "Email", value: "operations@placeupcareer.com", href: "mailto:operations@placeupcareer.com" },
                { icon: Globe, label: "Website", value: "placeupcareer.com", href: "https://placeupcareer.com/" },
                { icon: Phone, label: "Phone", value: "+1 (307) 400-5526", href: "tel:+13074005526" },
                { icon: MapPin, label: "Address", value: "30 N Gould St Ste N, Sheridan, WY 82801", href: undefined },
              ].map((item) => (
                <Card key={item.label} style={{ padding: "20px 22px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                    <div style={{
                      width: 42, height: 42, borderRadius: 11, background: "var(--pu-37-99-235-008)",
                      display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
                    }}>
                      <item.icon size={17} color={T.accent} />
                    </div>
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontSize: 11.5, fontWeight: 700, letterSpacing: "0.07em", textTransform: "uppercase", color: T.t3, fontFamily: F.sans, marginBottom: 3 }}>{item.label}</div>
                      {item.href
                        ? <a href={item.href} target={item.href.startsWith("http") ? "_blank" : undefined} rel="noopener noreferrer"
                            style={{ fontSize: 14.5, color: T.text, fontFamily: F.sans, fontWeight: 600, textDecoration: "none", wordBreak: "break-word" }}>{item.value}</a>
                        : <div style={{ fontSize: 14.5, color: T.text, fontFamily: F.sans, fontWeight: 600 }}>{item.value}</div>}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </Reveal>

          {/* Contact form */}
          <Reveal delay={0.18}>
            <Card hover={false} style={{ padding: 28 }}>
              {sent ? (
                <div style={{ textAlign: "center", padding: "48px 0" }}>
                  <div style={{
                    width: 56, height: 56, borderRadius: "50%", background: "var(--pu-34-197-94-012)",
                    display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 18px",
                  }}>
                    <Check size={26} color="var(--pu-16a34a)" strokeWidth={3} />
                  </div>
                  <div style={{ fontFamily: F.sans, fontSize: 19, fontWeight: 700, color: T.text, marginBottom: 8 }}>Message delivered</div>
                  <div style={{ fontSize: 14.5, color: T.t2, fontFamily: F.sans }}>
                    Your message was delivered to <strong>operations@placeupcareer.com</strong>. We will get back to you within 24 hours.
                  </div>
                  <button onClick={() => { setSent(false); setForm({ name: "", email: "", subject: "", message: "" }); }}
                    style={{ marginTop: 18, padding: "10px 18px", borderRadius: 10, border: `1px solid ${T.border}`, background: "var(--pu-ffffff-b)", color: T.t2, fontSize: 13.5, fontWeight: 600, fontFamily: F.sans, cursor: "pointer" }}>
                    Send another message
                  </button>
                </div>
              ) : (
                <div>
                  <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr", gap: 14, marginBottom: 14 }}>
                    <input placeholder="Full name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} style={inputStyle} />
                    <input placeholder="Email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} style={inputStyle} />
                  </div>
                  <select className="pu-light-select" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })}
                    style={{ ...inputStyle, marginBottom: 14, color: form.subject ? T.text : T.t3 }}>
                    <option value="">Subject</option>
                    <option>General Inquiry</option>
                    <option>Technical Support</option>
                    <option>Account Access</option>
                    <option>Partnership</option>
                  </select>
                  <textarea placeholder="Your message..." value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })}
                    style={{ ...inputStyle, height: 120, resize: "none", marginBottom: 14 }} />
                  {contactError && (
                    <div style={{ color: "var(--pu-dc2626)", fontSize: 13, fontFamily: F.sans, marginBottom: 12 }}>{contactError}</div>
                  )}
                  <button onClick={submitContact} disabled={submitting}
                    style={{
                      width: "100%", padding: "14px", borderRadius: 12, border: "none",
                      cursor: submitting ? "wait" : "pointer", background: T.grad, color: "var(--pu-ffffff-t)",
                      fontSize: 15.5, fontWeight: 700, fontFamily: F.sans,
                      display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
                      boxShadow: "0 8px 20px var(--pu-37-99-235-025)", opacity: submitting ? 0.75 : 1,
                    }}>
                    {submitting ? "Sending..." : "Send message"} <Send size={15} />
                  </button>
                </div>
              )}
            </Card>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

// ═══════════════════════════
// 6. FOOTER
// ═══════════════════════════
function Footer() {
  return (
    <div style={{ borderTop: `1px solid ${T.border}`, padding: "22px 24px", background: T.bgAlt }}>
      <div style={{
        maxWidth: 1100, margin: "0 auto", display: "flex", flexWrap: "wrap",
        alignItems: "center", justifyContent: "space-between", gap: 12,
      }}>
        <BrandLogo variant="dark" height={34} />
        <div style={{ display: "flex", gap: 20, flexWrap: "wrap" }}>
          {[
            { l: "Privacy", to: "/privacy" },
            { l: "Terms", to: "/terms" },
            { l: "Cookies", to: "/cookies" },
            { l: "Disclaimer", to: "/disclaimer" },
            { l: "Return Policy", to: "/return-policy" },
          ].map((item) => (
            <Link key={item.l} to={item.to} style={{ fontSize: 12.5, color: T.t3, textDecoration: "none", fontFamily: F.sans, fontWeight: 500 }}>{item.l}</Link>
          ))}
        </div>
        <span style={{ fontSize: 12.5, color: T.t3, fontFamily: F.sans }}>© 2026 PlaceUp Career</span>
      </div>
    </div>
  );
}
